/*
 * main.c
 *
 *  Created on: 2018/8/28
 *      Author: VLSILAB
 */

#include <stdio.h>
#include "xil_printf.h"
#include "xil_io.h"
#include "xparameters.h"
#include "PWM_controller.h"
#include "parity_generator.h"


int main()
{
	u32	R, G, B;
	u32 data;
	u32 bit;
	int choose;
	printf("Program Start.\n\r");
	while(getchar()!=EOF) {
		printf("which program you want to do?(1~5)\n");
		while(scanf("%d",&choose))
		{
			if(choose>5||choose<0)
			{
				printf("the number you input is invalid!please input again!\n");
				printf("which program you want to do?(1~5)\n");
				continue;
			}
			else
				break;
		}
		if(choose==1)
		{
			printf("input Red component(0~255):");
			scanf("%d", &R);
			printf(" %d\r\n", R);
			printf("input Green component(0~255):");
			scanf("%d", &G);
			printf(" %d\r\n", G);
			printf("input Blue component(0~255):");
			scanf("%d", &B);
			printf(" %d\r\n", B);
			PWM_controller(XPAR_PWM_CONTROLLER_0_S00_AXI_BASEADDR, R, G , B);
		}
		else if(choose==2)
		{

		}
		else if(choose==3)
		{
			printf("input data(0~4294967295):");
			while(scanf("%u",&data))
			{
				if(data>4294967295||data<0)
				{
					printf("invalid input!please input again!\n");
					printf("input data(0~4294967295):");
					continue;
				}
				else
					break;
			}
			printf("the data you input:");
			printf("%u\r\n", data);
			bit=parity_generator(XPAR_PARITY_GENERATOR_0_S00_AXI_BASEADDR, data);
			printf("%d\r\n",bit);
		}
		else if(choose==4)
		{

		}
		else
		{}


	}
	printf("Program End.\n\r");
    return 0;
}
