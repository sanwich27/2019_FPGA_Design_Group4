

/***************************** Include Files *******************************/
#include "sort.h"

/************************** Function Definitions ***************************/


u32 sort(UINTPTR baseAddr, u32 data1,u32 data2,u32 data3,u32 data4,u32 data5,u32 data6,u32 data7,u32 data8) {
	u32 data={data1+(data2<<4)+(data3<<8)+(data4<<12)+(data5<<16)+(data6<<20)+(data7<<24)+(data8<<28)};
	u32 sort_result;
	SORT_mWriteReg(baseAddr, 0, data);
	sort_result=SORT_mReadReg(baseAddr, 4);
	return sort_result;
}

