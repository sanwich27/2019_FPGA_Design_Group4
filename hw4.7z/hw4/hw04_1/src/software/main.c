/*
 * main.c
 *
 *  Created on: 2018/8/28
 *      Author: VLSILAB
 */

#include <stdio.h>
#include "xil_printf.h"
#include "xil_io.h"
#include "xparameters.h"
/*#include "PWM_controller.h"
#include "parity_generator.h"
#include "djb2.h"*/
#include "sort.h"


int main()
{
	int choose;
	printf("Program Start.\n\r");
	while(getchar()!=EOF) {
		printf("which program you want to do?(1~5)\n");
		while(scanf("%d",&choose))
		{
			if(choose>5||choose<0)
			{
				printf("the number you input is invalid!please input again!\n");
				printf("which program you want to do?(1~5)\n");
				continue;
			}
			else
				break;
		}
		if(choose==1)
		{
			u32 data1,data2,data3,data4,data5,data6,data7,data8;
			u32 sort_result;
			printf("sort\n");
			printf("input data1(0~15):");
			scanf("%d", &data1);
			printf(" %d\r\n", data1);
			printf("input data2(0~15):");
			scanf("%d", &data2);
			printf(" %d\r\n", data2);
			printf("input data3(0~15):");
			scanf("%d", &data3);
			printf(" %d\r\n", data3);
			printf("input data4(0~15):");
			scanf("%d", &data4);
			printf(" %d\r\n", data4);
			printf("input data5(0~15):");
			scanf("%d", &data5);
			printf(" %d\r\n", data5);
			printf("input data6(0~15):");
			scanf("%d", &data6);
			printf(" %d\r\n", data6);
			printf("input data7(0~15):");
			scanf("%d", &data7);
			printf(" %d\r\n", data7);
			printf("input data8(0~15):");
			scanf("%d", &data8);
			printf(" %d\r\n", data8);

			sort_result=sort(XPAR_SORT_0_S00_AXI_BASEADDR,data1,data2,data3,data4,data5,data6,data7,data8);
			//printf("sort result:%x",sort_result);
			printf("sort result:%d",(sort_result&0xf0000000)>>28);
			printf(",%d",(sort_result&0x0f000000)>>24);
			printf(",%d",(sort_result&0x00f00000)>>20);
			printf(",%d",(sort_result&0x000f0000)>>16);
			printf(",%d",(sort_result&0x0000f000)>>12);
			printf(",%d",(sort_result&0x00000f00)>>8);
			printf(",%d",(sort_result&0x000000f0)>>4);
			printf(",%d\n",(sort_result&0x0000000f));

		}
		else if(choose==2)
		{

		}
		else if(choose==3)
		{
			/*u32 parity_data;
			u32 parity_bit;
			printf("parity generator\n");
			printf("input data(0~4294967295):");
			while(scanf("%u",&parity_data))
			{
				if(parity_data>4294967295||parity_data<0)
				{
					printf("invalid input!please input again!\n");
					printf("input data(0~4294967295):");
					continue;
				}
				else
					break;
			}
			printf("the data you input:");
			printf("%u\r\n", parity_data);
			parity_bit=parity_generator(XPAR_PARITY_GENERATOR_0_S00_AXI_BASEADDR, parity_data);
			printf("%d\r\n",parity_bit);*/
		}
		else if(choose==4)
		{
			/*u8 hash_data;
			u32 hash_result;
			printf("djb2\n");
			printf("please input data(0~255):");
			while(scanf("%u",&hash_data))
			{
				if(hash_data>255||hash_data<0)
				{
					printf("invalid input!please input again!\n");
					printf("input data(0~255):");
					continue;
				}
				else
					break;
			}
			printf("the data you input:");
			printf("%u\r\n",hash_data);
			hash_result=djb2(XPAR_DJB2_0_S00_AXI_BASEADDR, hash_data);
			printf("hash result:%d\r\n",hash_result);*/
		}
		else
		{
			/*u32	R, G, B;
			printf("PWM_controller\n");
			printf("input Red component(0~255):");
			scanf("%d", &R);
			printf(" %d\r\n", R);
			printf("input Green component(0~255):");
			scanf("%d", &G);
			printf(" %d\r\n", G);
			printf("input Blue component(0~255):");
			scanf("%d", &B);
			printf(" %d\r\n", B);
			PWM_controller(XPAR_PWM_CONTROLLER_0_S00_AXI_BASEADDR, R, G , B);*/
		}


	}
	printf("Program End.\n\r");
    return 0;
}
