/*
 * main.c
 *
 *  Created on: 2018/8/28
 *      Author: VLSILAB
 */

#include <stdio.h>
#include "xil_printf.h"
#include "xil_io.h"
#include "xparameters.h"
#include "PWM_controller.h"
#include "parity_generator.h"
#include "djb2.h"


int main()
{
	int choose;
	printf("Program Start.\n\r");
	while(getchar()!=EOF) {
		printf("which program you want to do?(1~5)\n");
		while(scanf("%d",&choose))
		{
			if(choose>5||choose<0)
			{
				printf("the number you input is invalid!please input again!\n");
				printf("which program you want to do?(1~5)\n");
				continue;
			}
			else
				break;
		}
		if(choose==1)
		{

		}
		else if(choose==2)
		{

		}
		else if(choose==3)
		{
			u32 parity_data;
			u32 parity_bit;
			printf("parity generator\n");
			printf("input data(0~4294967295):");
			while(scanf("%u",&parity_data))
			{
				if(parity_data>4294967295||parity_data<0)
				{
					printf("invalid input!please input again!\n");
					printf("input data(0~4294967295):");
					continue;
				}
				else
					break;
			}
			printf("the data you input:");
			printf("%u\r\n", parity_data);
			parity_bit=parity_generator(XPAR_PARITY_GENERATOR_0_S00_AXI_BASEADDR, parity_data);
			printf("%d\r\n",parity_bit);
		}
		else if(choose==4)
		{
			u8 hash_data;
			u32 hash_result;
			printf("djb2\n");
			printf("please input data(0~255):");
			while(scanf("%u",&hash_data))
			{
				if(hash_data>255||hash_data<0)
				{
					printf("invalid input!please input again!\n");
					printf("input data(0~255):");
					continue;
				}
				else
					break;
			}
			printf("the data you input:");
			printf("%u\r\n",hash_data);
			hash_result=djb2(XPAR_DJB2_0_S00_AXI_BASEADDR, hash_data);
			printf("hash result:%d\r\n",hash_result);
		}
		else
		{
			u32	R, G, B;
			printf("PWM_controller\n");
			printf("input Red component(0~255):");
			scanf("%d", &R);
			printf(" %d\r\n", R);
			printf("input Green component(0~255):");
			scanf("%d", &G);
			printf(" %d\r\n", G);
			printf("input Blue component(0~255):");
			scanf("%d", &B);
			printf(" %d\r\n", B);
			PWM_controller(XPAR_PWM_CONTROLLER_0_S00_AXI_BASEADDR, R, G , B);
		}


	}
	printf("Program End.\n\r");
    return 0;
}
